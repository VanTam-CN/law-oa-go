import React from 'react'
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { MemoryRouter, Route, Routes } from 'react-router'
import { ApprovalDecisionFlow } from '../Batch01Prototype'

jest.mock('@/utils/storage', () => ({ getToken: () => 'test', getUserInfo: () => ({ id: '7', role: 'director' }), getRoles: () => [] }))
jest.mock('@/utils/messageHelper', () => ({ message: { success: jest.fn(), error: jest.fn(), warning: jest.fn(), info: jest.fn() } }))
const version = '2026-11-07T02:03:04.123456789Z'
let decisions: any[]
let failSnapshot = false
let legacyCurrent = false
beforeEach(() => {
  decisions = []; failSnapshot = false; legacyCurrent = false
  global.fetch = jest.fn(async (raw, options) => {
    const path = String(raw)
    let data: any = {}
    if (failSnapshot && path.includes('/snapshot')) throw new Error('版本读取中断')
    if (options?.method === 'POST') decisions.push(JSON.parse(String(options.body)))
    else if (path.includes('/snapshot')) data = {
      active_submission_snapshot_id: legacyCurrent ? null : 'current-snapshot',
      viewed_snapshot_id: path.includes('snapshot_id=old-snapshot') ? 'old-snapshot' : 'current-snapshot',
      submission_history: [{ id: 'current-snapshot', source_version: 2, snapshot_type: legacyCurrent ? 'conflict_approval' : 'intake_submission' }, { id: 'old-snapshot', source_version: 1, snapshot_type: 'conflict_approval' }],
      snapshot: { metadata: { case_creation_config: { title: path.includes('snapshot_id=old-snapshot') ? '历史提交标题' : '当前提交标题' } }, parties: [] },
    }
    else if (path.endsWith('/review')) data = { id: 'review-1', decision: 'no_conflict' }
    else if (path === '/api/v1/approvals/approval-uuid') data = {
      id: 'approval-uuid', title: '审批事项', applicant_id: '2', current_approver_id: '7', status: 'submitted', action_version: version, active_submission_snapshot_id: legacyCurrent ? null : 'current-snapshot', available_actions: ['approve', 'reject', 'request_changes'], conflict_check_id: 'check-1', conflict_result: { checkId: 'check-1', decision: { status: 'REVIEW_REQUIRED', coverageStatus: 'COMPLETE' } }, records: [],
    }
    return { ok: true, status: 200, json: async () => ({ data }) } as Response
  }) as jest.Mock
})
afterEach(cleanup)
function mount() {
  render(<MemoryRouter initialEntries={['/approval/approval-uuid']}><Routes><Route path='/approval/:id' element={<ApprovalDecisionFlow />} /></Routes></MemoryRouter>)
}
it('returns two structured requirements as an object with the exact server action version', async () => {
  mount()
  fireEvent.click(await screen.findByRole('button', { name: '退回修改' }))
  fireEvent.change(screen.getByLabelText('处理依据'), { target: { value: '请核对当前申请并分别补充以下两项说明' } })
  fireEvent.change(screen.getByLabelText('补正要求 1'), { target: { value: '说明第一项事项' } })
  fireEvent.click(screen.getByRole('button', { name: '增加补正要求' }))
  fireEvent.change(screen.getByLabelText('补正要求 2'), { target: { value: '说明第二项事项' } })
  fireEvent.click(screen.getByRole('button', { name: '确认退回修改' }))
  await waitFor(() => expect(decisions).toHaveLength(1))
  expect(decisions[0].expected_action_version).toBe(version)
  expect(decisions[0].expected_submission_snapshot_id).toBe('current-snapshot')
  expect(typeof decisions[0].imposed_requirements).toBe('object')
  expect(decisions[0].imposed_requirements.supplement_requests).toHaveLength(2)
  expect(decisions[0].imposed_requirements.supplement_requests[0]).toEqual(expect.objectContaining({ field_key: 'description', required: true }))
})

it('makes a historical snapshot read-only until switching back to the current submission', async () => {
  mount()
  await screen.findByRole('button', { name: '退回修改' })
  fireEvent.mouseDown(screen.getByRole('combobox', { name: '提交版本' }))
  fireEvent.click(await screen.findByText('第 1 次提交 · 历史只读'))
  await screen.findByText('正在查看历史提交版本，仅供查阅')
  expect(screen.getAllByText('历史提交标题').length).toBeGreaterThan(0)
  expect(screen.queryByText('当前提交标题')).not.toBeInTheDocument()
  expect(screen.queryByRole('button', { name: '退回修改' })).not.toBeInTheDocument()
  fireEvent.click(screen.getByRole('button', { name: '切回当前版本' }))
  await screen.findByRole('button', { name: '退回修改' })
  expect(decisions).toHaveLength(0)
})

it('disables decisions when the submission snapshot cannot be read', async () => {
  failSnapshot = true
  mount()
  await screen.findByText('提交版本读取失败，请重新加载后再处理审批')
  expect(screen.queryByRole('button', { name: '退回修改' })).not.toBeInTheDocument()
  expect(decisions).toHaveLength(0)
})

it('treats the server-verified legacy current snapshot as current and consumes the live review', async () => {
  legacyCurrent = true
  mount()
  const approve = await screen.findByRole('button', { name: /同意并成案/ })
  expect(approve).toBeEnabled()
  expect(screen.getByRole('button', { name: '退回修改' })).toBeEnabled()
  expect(screen.queryByText('正在查看历史提交版本，仅供查阅')).not.toBeInTheDocument()
  fireEvent.click(approve)
  fireEvent.change(screen.getByLabelText('处理依据'), { target: { value: '独立复核已完成并已核对当前申请事项' } })
  fireEvent.click(screen.getByRole('button', { name: '确认同意并成案' }))
  await waitFor(() => expect(decisions).toHaveLength(1))
  expect(decisions[0].expected_submission_snapshot_id).toBe('current-snapshot')
})

it('keeps explicitly selected legacy history read-only even with a null active pointer', async () => {
  legacyCurrent = true
  mount()
  await screen.findByRole('button', { name: '退回修改' })
  fireEvent.mouseDown(screen.getByRole('combobox', { name: '提交版本' }))
  fireEvent.click(await screen.findByText('第 1 次提交 · 历史只读'))
  await screen.findByText('正在查看历史提交版本，仅供查阅')
  expect(screen.queryByRole('button', { name: '退回修改' })).not.toBeInTheDocument()
  fireEvent.click(screen.getByRole('button', { name: '切回当前版本' }))
  await screen.findByRole('button', { name: '退回修改' })
})
